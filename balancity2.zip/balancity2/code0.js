gdjs.New_32sceneCode = {};


gdjs.New_32sceneCode.GDfloorObjects1= [];
gdjs.New_32sceneCode.GDtileObjects1= [];
gdjs.New_32sceneCode.GDhinge1Objects1= [];

gdjs.New_32sceneCode.conditionTrue_0 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_0 = {val:false};
gdjs.New_32sceneCode.conditionTrue_1 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_1 = {val:false};

gdjs.New_32sceneCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.New_32sceneCode.GDfloorObjects1.length = 0;
gdjs.New_32sceneCode.GDtileObjects1.length = 0;
gdjs.New_32sceneCode.GDhinge1Objects1.length = 0;


{

gdjs.New_32sceneCode.GDfloorObjects1.createFrom(runtimeScene.getObjects("floor"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition0IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = context.triggerOnce(314824684);
}
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDfloorObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDfloorObjects1[i].getBehavior("Physics").addRevoluteJoint((gdjs.New_32sceneCode.GDfloorObjects1[i].getPointX(""))+(gdjs.New_32sceneCode.GDfloorObjects1[i].getWidth())/2, (gdjs.New_32sceneCode.GDfloorObjects1[i].getPointY(""))+(gdjs.New_32sceneCode.GDfloorObjects1[i].getHeight())/3, runtimeScene);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.5, "", 0);
}}

}


{



}


{

gdjs.New_32sceneCode.GDtileObjects1.length = 0;

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition1IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = context.triggerOnce(314827204);
}
}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, context.clearEventsObjectsMap().addObjectsToEventsMap("tile", gdjs.New_32sceneCode.GDtileObjects1).getEventsObjectsMap(), gdjs.evtTools.input.getMouseX(runtimeScene, "", 0)-10, gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "");
}}

}


{



}

return;
}
gdjs['New_32sceneCode']= gdjs.New_32sceneCode;
